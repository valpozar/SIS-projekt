<?php 

system("notepad.exe "."info.txt");
header('location: komentari.php');
?>