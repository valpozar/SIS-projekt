<!DOCTYPE html>
<?php
include_once('baza.class.php');
$bp = new Baza();
$bp->spojiDB();

?>
<html>
    <head>
        <title>Prijava</title>
        <meta charset="UTF-8"/>
        <meta name="autor" content="mrukav">
        <meta name="naslov" content="Prijava">
    </head>
    <body>
         <style>

            * {box-sizing: border-box;}

            input[type=text],input[type=password], select, textarea {
                width: 100%;
                padding: 12px;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
                margin-top: 6px;
                margin-bottom: 16px;
                resize: vertical;
            }

            input[type=submit] {
                background-color: #00bcd4;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            input[type=submit]:hover {
                background-color: #acacac;
            }

            .ispis {
                border-radius: 5px;
                background-color: #f2f2f2;
                padding: 20px;
                margin-bottom:10%;
                width:60%;
                margin-left:20%;
            }


        </style>
        <?php
        $greska="";
        if (isset($_POST["prijava"])) {

            $korime = filter_input(INPUT_POST, 'korime', FILTER_SANITIZE_STRING);
            $lozinka = filter_input(INPUT_POST, 'lozinka', FILTER_SANITIZE_STRING);

            if (!empty($korime) && !empty($lozinka)) {
                $provjera = 'SELECT `korime`, `lozinka` FROM `korisnik`';
                $rs = $bp->selectDB($provjera);

                $nadjen = FALSE;
                while ($red = $rs->fetch_assoc()) {

                    if ($red['korime'] == $korime && $lozinka == $red['lozinka']) {
                        $nadjen = TRUE;
                    } else {
                        $korime = $korime;
                    }
                }
                if ($nadjen) {

                    $provjera = 'SELECT  `korime`, `lozinka` FROM `korisnik` WHERE `korime`="' . $korime . '" AND `lozinka`="' . $lozinka . '"';
                    $rs = $bp->selectDB($provjera);

                    while ($red = $rs->fetch_assoc()) {
                        $korime = $red['korime'];
                    }

                    //kolačić
                    $naziv = "SIS_projekt";
                    if (filter_input(INPUT_POST, 'pamti', FILTER_SANITIZE_STRING) == 1) {
                        $vrijedi_do = time() + 200;
                        setcookie($naziv, $korime, $vrijedi_do);
                    } else {
                        unset($_COOKIE[$naziv]);
                        setcookie($naziv, '', time() - 3800);
                    }
                    header('location: komentari.php');
                }else{
                    $greska="Korisnik ne postoji!";
                }
            }else{
                 $greska="Nisu upisani svi podaci!";
            }
        }
        ?> 

        <div class="ispis">

            <form method="post" name="prijava" action="<?php $_SERVER["PHP_SELF"]; ?>">

                <p><label for="korimeprijava">Korisničko ime: </label>
                    <input type="text" id="korimeprijava" name="korime" size="20" placeholder="korisničko ime"><br>

                    <label for="lozinka">Lozinka: </label>
                    <input type="password" id="lozinka" name="lozinka" size="15" placeholder="lozinka"><br>
                    
                    <input type="checkbox" name="pamti" value="1" checked="checked">Zapamti me<br>

                    <br><input type="submit" value=" Prijavi se " name="prijava">
                    <br><a href="zaboravljenaLozinka">Zaboravili ste lozinku?</a>
                <br><div><?php echo $greska ?></div>
                </p>

            </form>
        </div> 

    </body>
</html>
<?php
$bp->zatvoriDB();
?>