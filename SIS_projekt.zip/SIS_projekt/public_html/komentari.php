<?php
include_once('baza.class.php');

$poruka = "";

function ispis($nazivDatoteke) {
    $fn = $nazivDatoteke;
    $fp = fopen($fn, "r");
    $contents = fread($fp, filesize($fn));
    fclose($fp);
    echo $contents;
}

if (isset($_POST["spremi"])) {

    if (empty(filter_input(INPUT_POST, 'komentar', FILTER_SANITIZE_STRING))) {
        $poruka .= "Niste unijeli komentar!";
    }
    if (empty(filter_input(INPUT_POST, 'naslov', FILTER_SANITIZE_STRING))) {
        $poruka .= "Niste unijeli naslov!";
    }

    if ($poruka == "") {
        $naslov = filter_input(INPUT_POST, 'naslov', FILTER_SANITIZE_STRING);
        $komentar = filter_input(INPUT_POST, 'komentar', FILTER_SANITIZE_STRING);


        $file_name = "msgs.txt";
        $msg_begin = "~~~~MSG BEGIN~~~~\n";
        $msg_end = "~~~~MSG END~~~~\n";

        // If there is a submission, write it to the file on the server.
        if (($_REQUEST["naslov"] != "") && ($_REQUEST["komentar"] != "")) {
            
            $file1 = fopen("info.txt", "a+"); // Open/create file to write in append mode
            // Iterate through everything in the request string
            foreach ($_REQUEST as $key => $value) {
                fwrite($file1, $key . "=" . $value . "\n");
                fwrite($file1, "\n");
            }
            fclose($file1);

            $file = fopen($file_name, "a+"); // Open/create file to write in append mode
            fwrite($file, "\n");
            fwrite($file, $msg_begin);
            if (isset($_COOKIE["SIS_projekt"]))
                fwrite($file, "User: " . $_COOKIE["SIS_projekt"] . "\n");
            fwrite($file, "Date: " . date("r") . "\n");
            // If the post contains a quotation symbol (e.g. "), it is by default replaced
            // with a backslash and quote (\") when written to the file. The purpose of
            // stripslashes below is to remove the backslash when it is written to the
            // file. Note that this enables the Javascript to be inserted into the
            // subject or comment text unaltered, causing a potential XSS hole.
            fwrite($file, "Subject: " . stripslashes($_REQUEST["naslov"]) . "\n");
            fwrite($file, "Comment:\n" . stripslashes($_REQUEST["komentar"]) . "\n");
            fwrite($file, $msg_end);
            fwrite($file, "\n\n");
            fclose($file);

            ispis($file_name);
        }
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Komentari</title>
        <meta charset="UTF-8"/>
        <meta name="autor" content="mrukav">
        <meta name="naslov" content="Komentari">
    </head>
    <body>

        <style>

            * {box-sizing: border-box;}

            input[type=text], select, textarea {
                width: 100%;
                padding: 12px;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
                margin-top: 6px;
                margin-bottom: 16px;
                resize: vertical;
            }

            input[type=submit] {
                background-color: #00bcd4;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            input[type=submit]:hover {
                background-color: #acacac;
            }

            .ispis {
                border-radius: 5px;
                background-color: #f2f2f2;
                padding: 20px;
                margin-bottom:10%;
                width:60%;
                margin-left:20%;
            }


        </style>


        <div class="ispis">
            <form method="post" name="formaRecenzija" action="<?php $_SERVER["PHP_SELF"]; ?>">

                <label for="naslov">Naslov</label>
                <input type="text" name="naslov" placeholder="Naziv...">
                <label for="subject">Komentar</label>
                <textarea id="subject" name="komentar" placeholder="Napišite komentar..." style="height:200px"></textarea>

                <input type="submit" value="Objavi komentar" name="spremi">
            </form>

            <p style="text-align: center; color: red;"><?php echo $poruka; ?></p>
        </div>

    </body>
</html>



